# CD1-Pesquisar Duvidas
 
 **Autores**: Aluno e Professor.
 
 **Pré-Codições**: O	aluno estar cadastrado para acessar as dúvidas.
 
 **Fluxo Principal**:
 
   1. Informar os duvidas perguntadas.

# CD2-Indicar duplicatas
 
 **Autores**: Aluno e Professor
 
 **Pré-Codições**: Não há.
 
 **Fluxo Principal**:
 
   1. Mostrar que a pergunta (Que foi indicada como duplicata) ja tem resposta.

# CD3-Votar
 
 **Autores**: Aluno e Professor.
 
 **Pré-Codições**: O aluno estar cadastrado para acessar as dúvidas.
 
 **Fluxo Principal**:
 
   1. Quanto mais votos em respostas melhor posição se encontra.


