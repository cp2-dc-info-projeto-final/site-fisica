# Preparar um projeto particular de site para docentes

## Características:
Criação de um site particular para professores com o intuito de disponibilizar auxílio com as suas respectivas matérias para os alunos do Colégio Pedro II.

Especificações:
- Portal da matéria contendo exercícios específicos, recomendações de vídeo-aulas
e provas da matéria.
- Local do aluno, contendo cadastro de nome e senha, progresso e material submetido pelo aluno ao site.
- Local de comunicação com o professor, contendo telefone de contato, e-mail e caixa de comentário.
- Portal dos Alunos, contendo exercícios, provas e explicações dadas por alunos cadastrados, sistema de votação para todos e possibilidade de exclusão pelo administrador.
- Local de novidades da matéria, incluindo nome, descrição, data e/ou arquivos, como jornais científicos.
